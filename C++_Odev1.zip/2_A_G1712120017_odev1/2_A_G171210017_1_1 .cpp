#include<iostream>
using namespace std;

int main() {
	// 0 ile 24. sat�r aras� * bas�lacak. 0 dahil oldu�undan 24 dahil de�il.
	for (int sat�r = 0; sat�r < 24; sat�r++)
	{
		cout << "* ";
	}
	cout << endl;
	cout << "* S A U  B I L G I S A Y A R                  *" << endl;
	cout << "*                                             *" << endl;

	// sat�r = [0,6) aras� 0 dan ba�lay�p birer birer art�r�lacak
	for (int sat�r = 0; sat�r < 6; sat�r++)
	{
		// sutun = [0,24) aras� 0 dan ba�lay�p birer birer art�r�lacak
		for (int sutun = 0; sutun < 24; sutun++)
		{
			// e�er sutunlar 0 ve 23 �se * bas�lacak
			if ((sutun == 0) || (sutun == 23))
				cout << "* ";

			// sat�r = 5 ise * bas�lacak
			else if (sat�r == 5)
				cout << "* ";

			// sat�r ile sutun toplam� k���k e�it 5 ise bo�luk bas�lacak
			else if ((sat�r + sutun) <= 5)
				cout << "  ";

			// sat�r de�eri b�y�k e�it sutunun de�erinin 6 eksi�i ise * bas�lacak
			else if (sat�r >= sutun - 6)
				cout << "* ";

			// sat�r ile sutun toplam� 17 den k���kse bo�luk bas�lacak
			else if ((sat�r + sutun) < 17)
				cout << "  ";

			// sat�r de�eri sutun de�erinin 17 eksi�inden b�y�k veya e�itse * bas�lacak 
			else if (sat�r >= sutun - 17)
				cout << "* ";

			// sat�r 0 a ve sutun de�erleri 20 ya da 21 ya da 22 oldu�unda * bas�lacak
			else if ((sat�r == 0) && ((sutun == 20) || (sutun == 21) || (sutun == 22)))
				cout << "* ";

			// sat�r = 1 ve sutun = 21 oldu�unda * bas�lacak
			else if ((sat�r == 1) && (sutun == 21))
				cout << "* ";

			// yukar�daki ko�ullar� sa�lamad��� takdirde bo�luk bas�lacak
			else
				cout << "  ";
		}
		cout << endl;
	}
	cout << "*                                             *" << endl;
	cout << "* M U H E N D I S L I G I  B O L U M U        *" << endl;
	cout << "*                                             *" << endl;

	// sat�r de�eri 7 den ba�lat�l�p 13 e kadar birer birer art�r�lacak ( 13 dahil de�il )
	for (int sat�r = 7; sat�r < 13; sat�r++)
	{
		// sutun de�erini 0 dan ba�lat�p 24 e kadar art�r. ( 24 dahil de�il )
		for (int sutun = 0; sutun < 24; sutun++)
		{
			// sutun 0 ya da 23 e e�it oldu�unda * bas�lacak
			if ((sutun == 0) || (sutun == 23))
				cout << "* ";

			// sat�r = 12 oldu�unda * bas�lacak
			else if (sat�r == 12)
				cout << "* ";

			// sat�r ile sutun toplam� k���k e�it 12 ise bo�luk bas�lacak
			else if ((sat�r + sutun) <= 12)
				cout << "  ";

			// sat�r de�erinin 1 eksi�i b�y�k e�it sutun ise * bas�lacak
			else if (sat�r - 1 >= sutun)
				cout << "* ";

			// sat�r = 7 ve sutun de�eri 9 ya da 10 ya da 11 oldu�unda * bas�lacak
			else if ((sat�r == 7) && ((sutun == 9) || (sutun == 10) || (sutun == 11)))
				cout << "* ";

			// sat�r = 8 ve sutun = 10 ise * bas�lacak
			else if ((sat�r == 8) && (sutun == 10))
				cout << "* ";

			// sat�r ile sutun toplam� k���k e�it 23 oldu�unda bo�luk bas�lacak
			else if ((sat�r + sutun) <= 23)
				cout << "  ";

			// sat�r de�eri sutun de�erinin 10 eksi�inden b�y�k veya e�it oldu�unda * bas�lacak
			else if (sat�r >= sutun - 10)
				cout << "* ";

			// yukar�daki ko�ullar haricinde bir durum varsa bo�luk bas�lacak
			else
				cout << "  ";
		}
		cout << endl;
	}
	cout << "*                                             *" << endl;

	// sat�r de�eri 0 dan 24 e kadar birer birer art�r�l�p * bas�lacak ( 24 dahil edilmeyecek )
	for (int sat�r = 0; sat�r < 24; sat�r++)
	{
		cout << "* ";
	}
	cout << endl;
    
	system("PAUSE");
	return 0;
}



	
